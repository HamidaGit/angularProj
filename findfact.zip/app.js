var fs = require('fs');
var value = fs.readFileSync("input.txt").toString();

//Fill your code